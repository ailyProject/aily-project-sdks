/* generated configuration header file - do not edit */
#ifndef RM_VEE_FLASH_CFG_H_
#define RM_VEE_FLASH_CFG_H_
#ifdef __cplusplus
extern "C" {
#endif

#define RM_VEE_FLASH_CFG_PARAM_CHECKING_ENABLE ((BSP_CFG_PARAM_CHECKING_ENABLE))

#define RM_VEE_FLASH_CFG_REF_DATA_SUPPORT ((0))

#ifndef RM_VEE_FLASH_REFRESH_BUFFER_SIZE
#define RM_VEE_FLASH_REFRESH_BUFFER_SIZE        (32)
#endif

#ifdef __cplusplus
}
#endif
#endif /* RM_VEE_FLASH_CFG_H_ */
